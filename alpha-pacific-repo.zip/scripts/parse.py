#!/usr/bin/env python3
"""Parse the Alpha Pacific pulseMax deck into data/model.json.

The report is organised by channel, not by property. Campaign, ad-group and
creative strings carry the property name, so attribution is done by matching
those. Anything that can't be attributed is kept at portfolio level and
labelled as such rather than split by guesswork.
"""
import re, json, pathlib
from pptx import Presentation

ROOT = pathlib.Path(__file__).resolve().parent.parent
DECK = ROOT / "source-reports"

PROPS = {
    "CAN": {"name": "Camino Al Norte", "site": "https://caminoalnorteapts.com/",
            "accent": "#C2691D", "match": r"camino\s*al\s*norte"},
    "ONX": {"name": "The Onyx",        "site": "https://theonyxapartments.com/",
            "accent": "#2F6FED", "match": r"\bonyx\b"},
    "ELY": {"name": "Elysian at St. Rose", "site": "https://elysianatstrose.com/",
            "accent": "#0E9F6E", "match": r"elysian|st\.?\s*rose"},
}
ORDER = ["CAN", "ONX", "ELY"]

# "Search & Intent Media" repeats the SEM section verbatim (verified: identical
# impressions, clicks and conversions). Skipped so SEM isn't double counted.
SKIP = {"Search & Intent Media", "Overview"}
DIVIDERS = {"Geo-Fencing w/Foot Traffic": "Display",
            "Meta": "Social",
            "SEM": "SEM",
            "Call Performance": "Calls"}

WEEK = re.compile(r"^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{1,2}$")

def prop_of(text):
    t = (text or "").lower()
    for k, v in PROPS.items():
        if re.search(v["match"], t): return k
    return None

def num(s):
    if s is None: return 0
    s = str(s).strip().replace(",", "").replace("$", "").replace("%", "")
    if s in ("", "-", "\u2014", "None", "N/A"): return 0
    try:
        f = float(s)
        return int(f) if f == int(f) else round(f, 2)
    except: return 0

def isnum(s):
    s = str(s).strip().replace(",", "").replace("%", "").replace("$", "")
    if s in ("", "-", "\u2014"): return False
    try: float(s); return True
    except: return False

def isval(s):
    return isnum(s) or str(s).strip() in ("-", "\u2014", "", "N/A", "None")

def slides():
    f = next(DECK.glob("*.pptx"))
    out = []
    for slide in Presentation(f).slides:
        lines = []
        for sh in slide.shapes:
            if sh.has_text_frame:
                for p in sh.text_frame.paragraphs:
                    t = "".join(r.text for r in p.runs).strip()
                    if t: lines.append(t)
            if sh.has_table:
                for row in sh.table.rows:
                    for c in row.cells:
                        t = c.text.strip()
                        if t: lines.append(t)
        out.append(lines)
    return out

def find_table(lines, header):
    n = len(header); hset = set(header); out = []
    for i in range(len(lines) - n + 1):
        if lines[i:i+n] != header: continue
        rest = lines[i+n:]
        need = max(1, n - 2)
        for j in range(0, len(rest) - n + 1, n):
            chunk = rest[j:j+n]
            if any(c in hset for c in chunk): break
            if sum(1 for c in chunk if isval(c)) < need: break
            out.append(chunk)
        break
    return out

def clean_name(s):
    """Strip the account prefix so names read like names."""
    s = re.sub(r"^\d+_[A-Z]{2}_[A-Za-z]+_Alpha Pacific Capital_?", "", s or "")
    s = re.sub(r"^Alpha Pacific Capital\s*", "", s)
    return re.sub(r"\s+", " ", s).strip(" _-")

def mmss(h):
    m = re.match(r"^(\d+):(\d+):(\d+)$", h or "")
    return int(m.group(1))*3600 + int(m.group(2))*60 + int(m.group(3)) if m else 0

S = slides()
period = "Aug 19 – Sep 29, 2026"

model = {p: {"key": p, **PROPS[p],
             "channels": {}, "creatives": {}, "adGroups": [], "keywords": [],
             "campaigns": []} for p in PROPS}
shared = {"channels": {}, "geo": [], "zones": [], "fences": [], "calls": [],
          "callLog": [], "callStatus": {}, "keywords": [], "devices": [],
          "platforms": [], "period": period,
          # monthly[channel][MM-YYYY] — the ONLY month split this deck carries.
          # It is account level: no tactic reports a month broken out by property.
          "monthly": {}, "zips": [], "semConv": [], "metaAdSets": [],
          "metaWeekly": [], "semWeekly": []}

ch, skipping = None, False
for lines in S:
    if len(lines) == 1:
        if lines[0] in SKIP: skipping, ch = True, None; continue
        if lines[0] in DIVIDERS: skipping, ch = False, DIVIDERS[lines[0]]; continue
    if skipping and "Top KPIs" not in " ".join(lines) \
       and "Key Performance Indicators" not in " ".join(lines): continue

    # ---- channel level KPI panels (portfolio totals) ----------------------
    for label, key in (("Display - Top KPIs", "Display"),
                       ("Key Performance Indicators (Display)", "Social"),
                       ("Key Performance Indicator", "SEM")):
        if label in lines and (key != "SEM" or ch == "SEM"):
            i = lines.index(label)
            kpi = {}
            for j in range(i+1, min(i+22, len(lines))-1):
                if lines[j] in ("Impressions","Clicks","CTR(%)","Engagement",
                                "Total Conversions","Total Conversions/Leads",
                                "Primary Conversions","All Conversions"):
                    v = lines[j+1]
                    mult = 1000 if v.endswith("K") else 1
                    if isnum(v.rstrip("K")):
                        kpi[lines[j]] = round(num(v.rstrip("K")) * mult) if mult > 1 else num(v)
            shared["channels"][key] = kpi

    # ---- Monthly Performance (account level, one table per tactic) --------
    for hdr, key, cols in (
        (["Date","Impressions","Clicks","CTR(%)","Foot Traffic Visits",
          "Total Conversions"], "Display",
         {"impressions":1, "clicks":2, "ctr":3, "visits":4, "conversions":5}),
        (["Date","Impressions","Link Clicks","CTR(Link Click-Through Rate)",
          "Post Engagements","Conversions (Default)","Total Leads"], "Social",
         {"impressions":1, "clicks":2, "ctr":3, "engagement":4, "leads":6,
          "conversions":6}),
        (["Date","Impressions","Clicks","CTR(%)","Primary Conversions",
          "Primary Conv. Rate(%)","All Conversions","All Conv. Rate(%)"], "SEM",
         {"impressions":1, "clicks":2, "ctr":3, "conversions":6}),
        (["Date","Total Calls","First Calls","Answered Calls","Answered(%)",
          "Average Duration"], "Calls",
         {"calls":1, "first":2, "answered":3}),
    ):
        for r in find_table(lines, hdr):
            if not re.match(r"^\d{2}-\d{4}$", r[0]): continue
            m = shared["monthly"].setdefault(key, {}).setdefault(r[0], {})
            for f, i in cols.items(): m[f] = num(r[i])
            if key == "Calls": m["avgDur"] = r[5]

    # ---- Display: geofencing campaigns, creatives, target fences ----------
    for r in find_table(lines, ["Campaign Name","Impressions","Clicks","CTR(%)",
                                "Foot Traffic Visits","Total Conversions"]):
        p = prop_of(r[0])
        rec = {"channel": "Display", "name": clean_name(r[0]), "impressions": num(r[1]),
               "clicks": num(r[2]), "ctr": num(r[3]), "visits": num(r[4]),
               "conversions": num(r[5])}
        (model[p]["campaigns"] if p else shared.setdefault("campaigns", [])).append(rec)
        if p: model[p]["channels"].setdefault("Display", {"impressions":0,"clicks":0,
              "visits":0,"conversions":0,"engagement":0,"leads":0})
        if p:
            c = model[p]["channels"]["Display"]
            c["impressions"] += rec["impressions"]; c["clicks"] += rec["clicks"]
            c["visits"] += rec["visits"]; c["conversions"] += rec["conversions"]

    for r in find_table(lines, ["Creative Set","Impressions","Clicks","CTR(%)",
                                "Site Conversions","Foot Traffic Visits"]):
        p = prop_of(r[0])
        if p: model[p]["creatives"].setdefault("Display", []).append(
            {"name": clean_name(r[0]), "impressions": num(r[1]), "clicks": num(r[2]),
             "ctr": num(r[3]), "size": ""})

    for r in find_table(lines, ["Creative","Impressions","Clicks","CTR(%)",
                                "Foot Traffic Visits","Total Conversions"]):
        p = prop_of(r[0])
        size = (re.search(r"_(\d+x\d+)_", r[0]) or [None, ""])[1]
        if p: model[p]["creatives"].setdefault("Display sizes", []).append(
            {"name": clean_name(r[0]), "impressions": num(r[1]), "clicks": num(r[2]),
             "ctr": num(r[3]), "size": size})

    for r in find_table(lines, ["Target Fence","Impressions","Clicks","CTR(%)",
                                "Foot Traffic Visits","Total Conversions"]):
        shared["fences"].append({"name": re.sub(r"\s+", " ", r[0]).strip(),
                                 "impressions": num(r[1]), "clicks": num(r[2]),
                                 "visits": num(r[4])})
    for r in find_table(lines, ["State","Zip Code","Impressions","Clicks","CTR(%)",
                                "Foot Traffic Visits","Total Conversions"]):
        shared["zips"].append({"state": r[0], "zip": r[1], "impressions": num(r[2]),
                               "clicks": num(r[3]), "ctr": num(r[4]),
                               "visits": num(r[5])})

    for r in find_table(lines, ["Conversion Geo Fence Name","Clickthrough Visits",
                                "Viewthrough Visits","Foot Traffic Visits","Total Conversions"]):
        if r[0] == "None": continue
        shared["zones"].append({"name": re.sub(r"\s+", " ", r[0]).strip(),
                                "visits": num(r[3]), "conversions": num(r[4])})

    # ---- Social (Meta) ---------------------------------------------------
    for r in find_table(lines, ["Campaign","Impressions","Link Clicks",
                                "CTR(Link Click-Through Rate)","Post Engagements","Total Leads"]):
        p = prop_of(r[0])
        rec = {"channel": "Social", "name": clean_name(r[0]), "impressions": num(r[1]),
               "clicks": num(r[2]), "ctr": num(r[3]), "engagement": num(r[4]),
               "leads": num(r[5]), "visits": 0, "conversions": num(r[5])}
        if p:
            model[p]["campaigns"].append(rec)
            c = model[p]["channels"].setdefault("Social", {"impressions":0,"clicks":0,
                "visits":0,"conversions":0,"engagement":0,"leads":0})
            c["impressions"] += rec["impressions"]; c["clicks"] += rec["clicks"]
            c["engagement"] += rec["engagement"]; c["leads"] += rec["leads"]
            c["conversions"] += rec["leads"]

    for r in find_table(lines, ["Creative Name","Impressions","Link Clicks",
                                "CTR (Link Click-Through Rate)","Post Shares","Post Engagements"]):
        p = prop_of(r[0])
        if p: model[p]["creatives"].setdefault("Social", []).append(
            {"name": clean_name(r[0]), "impressions": num(r[1]), "clicks": num(r[2]),
             "ctr": num(r[3]), "engagement": num(r[5]), "size": ""})

    # ---- SEM -------------------------------------------------------------
    # SEM attribution runs off the campaign table, not the ad-group table: the
    # deck prints only the top five ad groups (27,044 of 29,046 impressions),
    # whereas the three campaigns are one per property and reconcile exactly.
    for r in find_table(lines, ["Campaign Name","Impressions","Clicks","CTR",
                                "Primary Conversions","Primary Conversion Rate",
                                "All Conversions","All Conversions Rate"]):
        p = prop_of(r[0])
        rec = {"channel": "SEM", "name": clean_name(r[0]), "impressions": num(r[1]),
               "clicks": num(r[2]), "ctr": num(r[3]), "visits": 0,
               "conversions": num(r[6])}
        (model[p]["campaigns"] if p else shared.setdefault("campaigns", [])).append(rec)

    for r in find_table(lines, ["Ad Group","Impressions","Clicks","CTR(%)",
                                "Primary Conversions","All Conversions"]):
        p = prop_of(r[0])
        rec = {"name": clean_name(r[0]), "impressions": num(r[1]), "clicks": num(r[2]),
               "ctr": num(r[3]), "conversions": num(r[5])}
        if p:
            model[p]["adGroups"].append(rec)
            c = model[p]["channels"].setdefault("SEM", {"impressions":0,"clicks":0,
                "visits":0,"conversions":0,"engagement":0,"leads":0})
            c["impressions"] += rec["impressions"]; c["clicks"] += rec["clicks"]
            c["conversions"] += rec["conversions"]

    for r in find_table(lines, ["Keyword","Impressions","Clicks","CTR(%)","Primary Conversions",
                                "Primary Conversion Rate","All Conversions","All Conv. Rate(%)"]):
        rec = {"name": r[0], "impressions": num(r[1]), "clicks": num(r[2]),
               "ctr": num(r[3]), "conversions": num(r[6])}
        p = prop_of(r[0])
        (model[p]["keywords"] if p else shared["keywords"]).append(rec)

    # ---- Meta detail (Meta runs for Onyx only, so this is Onyx's data) ----
    for r in find_table(lines, ["Platform","Impressions","Link Clicks",
                                "CTR (Link Click-Through Rate)","Post Engagements",
                                "Video Thruplay","Total Leads"]):
        shared.setdefault("metaPlatform", []).append(
            {"name": r[0], "impressions": num(r[1]), "clicks": num(r[2]),
             "ctr": num(r[3]), "engagement": num(r[4]), "leads": num(r[6])})
    # Age breakdown deliberately not carried through: housing advertising is a
    # Fair Housing sensitive category and the client asked to keep it out.
    for r in find_table(lines, ["Gender","Impressions","Link Clicks",
                                "CTR (Link Click-Through Rate)","Total Leads"]):
        shared.setdefault("metaGender", []).append(
            {"name": r[0], "impressions": num(r[1]), "clicks": num(r[2]),
             "ctr": num(r[3]), "leads": num(r[4])})
    for r in find_table(lines, ["Tactic","Impressions","Reach","Frequency"]):
        shared["metaReach"] = {"impressions": num(r[1]), "reach": num(r[2]),
                               "frequency": num(r[3])}
    for r in find_table(lines, ["Campaign Name","Post Engagement","Page Likes",
                                "Post Comments","Post Shares","Post Reactions",
                                "Photo Views","Link Clicks","Video 3-Second Views"]):
        shared["metaPost"] = {"engagement": num(r[1]), "likes": num(r[2]),
                              "shares": num(r[4]), "reactions": num(r[5]),
                              "clicks": num(r[7])}
    for r in find_table(lines, ["Date","Impressions","Link Clicks",
                                "CTR(Link Click-Through Rate)","Post Engagements",
                                "Conversions (Default)","Total Leads"]):
        if re.match(r"^\d{2}-\d{4}$", r[0]):
            shared.setdefault("metaMonthly", []).append(
                {"date": r[0], "impressions": num(r[1]), "clicks": num(r[2]),
                 "ctr": num(r[3]), "leads": num(r[6])})
    for r in find_table(lines, ["Ad Set Name","Objective","Impressions","Link Clicks",
                                "CTR (Link Click-Through Rate)","Post Engagement",
                                "Total Leads"]):
        shared["metaAdSets"].append({"name": r[0], "impressions": num(r[2]),
                                     "clicks": num(r[3]), "ctr": num(r[4]),
                                     "leads": num(r[6])})
    for r in find_table(lines, ["Date","Impressions","Link Clicks","CTR(%)",
                                "Post Engagements","Conversions (Default)","Total Leads"]):
        if WEEK.match(r[0]):
            shared["metaWeekly"].append({"week": r[0], "impressions": num(r[1]),
                                         "clicks": num(r[2]), "ctr": num(r[3]),
                                         "leads": num(r[6])})
    # the weekly table runs off the end of its slide; the overflow arrives as a
    # bare 7-cell run with no header, so pick it up by shape.
    if shared["metaWeekly"] and WEEK.match(lines[0] if lines else ""):
        for j in range(0, len(lines) - 6, 7):
            if WEEK.match(lines[j]) and all(isval(c) for c in lines[j+1:j+7]):
                shared["metaWeekly"].append({"week": lines[j],
                                             "impressions": num(lines[j+1]),
                                             "clicks": num(lines[j+2]),
                                             "ctr": num(lines[j+3]),
                                             "leads": num(lines[j+6])})

    for r in find_table(lines, ["Comscore Market","Impressions","Link Clicks"]):
        shared.setdefault("metaGeo", []).append(
            {"name": r[0], "impressions": num(r[1]), "clicks": num(r[2])})

    # ---- SEM detail -------------------------------------------------------
    for r in find_table(lines, ["Device Type","Impressions","Clicks","CTR(%)",
                                "Primary Conversions","All Conversions"]):
        shared.setdefault("semDevices", []).append(
            {"name": r[0], "impressions": num(r[1]), "clicks": num(r[2]), "ctr": num(r[3])})
    for r in find_table(lines, ["City","State","Impressions","Clicks","CTR(%)"]):
        shared.setdefault("semGeo", []).append(
            {"name": r[0], "state": r[1], "impressions": num(r[2]), "clicks": num(r[3])})
    for r in find_table(lines, ["Platform","Impressions","Clicks","CTR(%)",
                                "Primary Conversions","All Conversions"]):
        shared.setdefault("semPlatform", []).append(
            {"name": r[0], "impressions": num(r[1]), "clicks": num(r[2]), "ctr": num(r[3])})

    for r in find_table(lines, ["Conversion Action Name","Primary Conversions",
                                "All Conversions"]):
        (shared["semWeekly"] if WEEK.match(r[0]) else shared["semConv"]).append(
            {"name": r[0], "conversions": num(r[2])})

    # ---- geography, devices, calls ---------------------------------------
    for r in find_table(lines, ["City","Region","Impressions","Clicks","CTR(%)",
                                "Foot Traffic Visits","Total Conversions"]):
        shared["geo"].append({"city": r[0], "state": r[1], "impressions": num(r[2]),
                              "clicks": num(r[3]), "visits": num(r[5])})
    for r in find_table(lines, ["Device","Impressions","Clicks","CTR(%)",
                                "Foot Traffic Visits","Total Conversions"]):
        shared["devices"].append({"name": r[0], "impressions": num(r[1]), "clicks": num(r[2])})
    for r in find_table(lines, ["Date","Total Calls","First Calls","Answered Calls",
                                "Answered(%)","Average Duration"]):
        shared["calls"].append({"date": r[0], "total": num(r[1]), "answered": num(r[3]),
                                "avgDur": r[5]})

    if "Caller Information" in lines:
        i = lines.index("Caller Information"); j = i
        while j < len(lines):
            if re.match(r"^\d{4}-\d{2}-\d{2}$", lines[j]):
                k, cells = j+1, []
                while k < len(lines) and not re.match(r"^\d{4}-\d{2}-\d{2}$", lines[k]):
                    cells.append(lines[k]); k += 1
                    if cells and cells[-1].startswith("CAL"): break
                if cells and cells[-1].startswith("CAL"):
                    shared["callLog"].append({
                        "date": lines[j], "source": cells[0],
                        "name": cells[1] if len(cells) > 1 else "",
                        "number": cells[2] if len(cells) > 2 else "",
                        "duration": next((c for c in cells if re.match(r"^\d{2}:\d{2}:\d{2}$", c)), ""),
                        "recording": next((c for c in cells if c.startswith("http")), ""),
                        "id": cells[-1]})
                j = k; continue
            j += 1

    if "Call Summary Information" in lines:
        i = lines.index("Call Summary Information")
        for j in range(i, len(lines)):
            if lines[j].startswith("CAL"):
                seg = lines[max(i, j-6):j]
                summ = max(seg, key=len) if seg else ""
                shared["callStatus"][lines[j]] = {
                    "answered": "yes" in [x.lower() for x in seg],
                    "summary": summ if len(summ) > 40 else ""}

for c in shared["callLog"]:
    st = shared["callStatus"].get(c["id"], {})
    c["answered"] = bool(st.get("answered")); c["summary"] = st.get("summary", "")
    c["sec"] = mmss(c["duration"])

# de-duplicate repeated tables (the deck prints several the same twice)
def uniq(rows, key):
    seen, out = set(), []
    for r in rows:
        k = key(r)
        if k in seen: continue
        seen.add(k); out.append(r)
    return out

for p in model.values():
    p["campaigns"] = uniq(p["campaigns"], lambda r: (r["channel"], r["name"], r["impressions"]))
    p["adGroups"]  = uniq(p["adGroups"],  lambda r: (r["name"], r["impressions"]))
    p["keywords"]  = uniq(p["keywords"],  lambda r: (r["name"], r["impressions"]))
    for k in p["creatives"]:
        p["creatives"][k] = uniq(p["creatives"][k], lambda r: (r["name"], r["impressions"]))
    # channel totals were summed over duplicated tables — rebuild from unique rows
    p["channels"] = {}
    for r in p["campaigns"]:
        c = p["channels"].setdefault(r["channel"], {"impressions":0,"clicks":0,"visits":0,
                                                    "conversions":0,"engagement":0,"leads":0})
        for f in ("impressions","clicks","visits","conversions","engagement","leads"):
            c[f] += r.get(f, 0)
    # fall back to ad groups only where no SEM campaign was attributed
    if p["adGroups"] and "SEM" not in p["channels"]:
        c = p["channels"].setdefault("SEM", {"impressions":0,"clicks":0,"visits":0,
                                             "conversions":0,"engagement":0,"leads":0})
        for r in p["adGroups"]:
            c["impressions"] += r["impressions"]; c["clicks"] += r["clicks"]
            c["conversions"] += r["conversions"]

shared["geo"]     = uniq(shared["geo"],     lambda r: (r["city"], r["state"], r["impressions"]))
shared["fences"]  = uniq(shared["fences"],  lambda r: (r["name"], r["impressions"]))
shared["zones"]   = uniq(shared["zones"],   lambda r: r["name"])
shared["calls"]   = uniq(shared["calls"],   lambda r: r["date"])
shared["callLog"] = uniq(shared["callLog"], lambda r: r["id"])
shared["keywords"]= uniq(shared["keywords"],lambda r: (r["name"], r["impressions"]))
shared["devices"] = uniq(shared["devices"], lambda r: r["name"])
shared["zips"]     = uniq(shared["zips"],     lambda r: (r["zip"], r["impressions"]))
shared["semConv"]  = uniq(shared["semConv"],  lambda r: r["name"])
shared["metaAdSets"] = uniq(shared["metaAdSets"], lambda r: (r["name"], r["impressions"]))
shared["metaWeekly"] = uniq(shared["metaWeekly"], lambda r: r["week"])
shared["semWeekly"]  = uniq(shared["semWeekly"],  lambda r: r["name"])
for k in ("metaPlatform","metaGender","metaGeo","metaMonthly",
          "semDevices","semGeo","semPlatform"):
    if k in shared: shared[k] = uniq(shared[k], lambda r: (r.get("name") or r.get("date"),
                                                          r["impressions"]))

out = {"client": "Alpha Pacific Capital", "period": period,
       "order": ORDER, "properties": model, "shared": shared}
(ROOT / "data").mkdir(exist_ok=True)
(ROOT / "data" / "model.json").write_text(json.dumps(out, separators=(",", ":")))

for p in ORDER:
    m = model[p]
    print(f"{m['name']:22s}", {k: v["impressions"] for k, v in m["channels"].items()},
          f"adGroups={len(m['adGroups'])} kw={len(m['keywords'])}",
          f"creatives={ {k: len(v) for k, v in m['creatives'].items()} }")
print("\nshared:", {k: (len(v) if isinstance(v, (list, dict)) else v)
                    for k, v in shared.items() if k != "period"})
print("channel KPI panels:", shared["channels"])
tot = {}
for m in model.values():
    for k, v in m["channels"].items(): tot[k] = tot.get(k, 0) + v["impressions"]
print("attributed vs account:", tot, "| account SEM 29046 Display 157420 Social 44028")
print("monthly:", {k: {m: v["impressions"] for m, v in d.items()}
                   for k, d in shared["monthly"].items() if k != "Calls"})
print("calls/mo:", shared["monthly"].get("Calls"))
print("zips:", len(shared["zips"]), "semConv:", shared["semConv"],
      "adSets:", len(shared["metaAdSets"]), "weekly:", len(shared["metaWeekly"]))
print("bytes:", (ROOT / "data" / "model.json").stat().st_size)
