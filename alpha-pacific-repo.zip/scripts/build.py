#!/usr/bin/env python3
"""Assemble index.html from the template and data/model.json."""
import json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
tpl = (ROOT / "scripts" / "template.html").read_text()
src = ROOT / "data" / "model.json"
if not src.exists(): sys.exit("run scripts/parse.py first")
model = json.loads(src.read_text())

# The call panel was removed at the client's request, but the parser still fills
# the call log — caller names, phone numbers and CallRail recording URLs for
# private individuals. Inlining that into index.html would publish it to anyone
# who opens the file or the repo, whether or not anything renders it. So it is
# stripped here rather than at parse time: data/model.json keeps everything, and
# restoring the panel is a template change plus deleting these three lines.
STRIP = ("callLog", "callStatus")
redacted = {k: v for k, v in model.items()}
redacted["shared"] = {k: v for k, v in model["shared"].items() if k not in STRIP}
dropped = sum(len(model["shared"].get(k) or []) for k in STRIP)
data = json.dumps(redacted, separators=(",", ":"))
# Meta lead roster: names, emails and phone numbers for real people who enquired
# about an apartment. `--public` keeps the counts and drops every row, for any
# build that leaves the leasing team.
PUBLIC = "--public" in sys.argv
lp = ROOT / "data" / "leads.json"
leads = json.loads(lp.read_text()) if lp.exists() else {}
if PUBLIC:
    for v in leads.values(): v["rows"] = []
leads_js = json.dumps(leads, separators=(",", ":"))

kwp = ROOT / "data" / "keywords.json"
kw = kwp.read_text() if kwp.exists() else "{}"
json.loads(kw)
out = (tpl.replace("__DATA__", data).replace("__KEYWORDS__", kw)
          .replace("__LEADS__", leads_js))
assert not any(t in out for t in ("__DATA__", "__KEYWORDS__", "__LEADS__"))
dest = ROOT / ("index-public.html" if PUBLIC else "index.html")
dest.write_text(out)
held = sum(len(v.get("rows") or []) for v in
           (json.loads(lp.read_text()) if lp.exists() else {}).values()) if PUBLIC else 0
print(f"wrote {dest.name} ({len(out):,} bytes) \u00b7 held back {dropped} call records"
      + (f" and {held} lead records" if PUBLIC else ""))
if not PUBLIC:
    n = sum(len(v.get("rows") or []) for v in leads.values())
    if n:
        print(f"  note: {n} lead records (names, emails, phone numbers) are inside "
              f"{dest.name}.\n"
              f"        For anything public run: python3 scripts/build.py --public")
