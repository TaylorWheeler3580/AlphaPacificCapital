#!/usr/bin/env python3
"""Parse the Meta lead-gen export into data/leads.json.

Only columns A–E are carried: date, first name, last name, email, phone. The
later columns (lifestyle, household, priorities, budget, lead status) are read
only to count how complete the export is, and are not written out.

The rows are contact details for private individuals. data/leads.json is
gitignored, build.py masks email and phone in the page, and `build.py --public`
drops the roster entirely. See README.
"""
import json, pathlib, re, datetime
import openpyxl

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "source-reports" / "onyx_meta_leads.xlsx"

# Meta runs a single lead-gen campaign, for The Onyx. The workbook carries a
# sheet per property; the other two are empty and stay that way until they run.
SHEETS = {"Onyx": "ONX", "Camino": "CAN", "Elysian": "ELY"}


def phone(v):
    """Digits only in, readable US format out. Anything unexpected passes through."""
    d = re.sub(r"\D", "", str(v or ""))
    if len(d) == 11 and d.startswith("1"): d = d[1:]
    if len(d) == 10: return f"({d[:3]}) {d[3:6]}-{d[6:]}"
    return str(v or "").strip()


def cell(v):
    return re.sub(r"\s+", " ", str(v).strip()) if v is not None else ""


PLATFORM = {"ig": "Instagram", "fb": "Facebook",
            "instagram": "Instagram", "facebook": "Facebook"}


def fields(r):
    """Locate first name, last name, email and phone in a row.

    The supplied workbook is two exports stacked: 36 rows are Date / First /
    Last / Email / Phone, and 107 carry an extra platform column at B that
    shifts everything one to the right. Reading by position would put "fb" in
    the first-name column and slide the phone number out of view, so the email
    cell is found first and the rest are read relative to it.
    """
    ei = next((i for i, v in enumerate(r)
               if isinstance(v, str) and "@" in v and "." in v), None)
    if ei is None or ei < 2:                       # no email: fall back to A–E
        return cell(r[1]), cell(r[2]), cell(r[3]), r[4] if len(r) > 4 else "", ""
    plat = ""
    if ei >= 4:
        plat = PLATFORM.get(cell(r[ei - 3]).lower(), "")
    return (cell(r[ei - 2]), cell(r[ei - 1]), cell(r[ei]),
            r[ei + 1] if len(r) > ei + 1 else "", plat)


out = {}
wb = openpyxl.load_workbook(SRC, data_only=True)
for sheet, key in SHEETS.items():
    if sheet not in wb.sheetnames: continue
    ws = wb[sheet]
    rows, counts, undated, dates = [], {}, 0, []
    for r in ws.iter_rows(min_row=2, values_only=True):
        if not any(x is not None for x in r[:5]): continue
        d = r[0]
        if isinstance(d, datetime.datetime):
            mk = d.strftime("%m-%Y"); dates.append(d)
            ds, dsort = d.strftime("%b %-d"), d.isoformat()
        else:
            # one row in the supplied export has no timestamp; it is kept and
            # shown rather than dropped, but it cannot be placed in a month
            mk, ds, dsort = "", "—", ""
            undated += 1
        f, l, e, ph, plat = fields(r)
        rows.append({"m": mk, "d": ds, "s": dsort,
                     "f": f, "l": l, "e": e, "p": phone(ph), "src": plat})
        if mk: counts[mk] = counts.get(mk, 0) + 1

    if not rows: continue
    rows.sort(key=lambda x: x["s"], reverse=True)
    emails = [x["e"].lower() for x in rows if x["e"]]
    plat = {}
    for x in rows:
        if x["src"]: plat[x["src"]] = plat.get(x["src"], 0) + 1
    out[key] = {
        "rows": rows,
        "counts": counts,
        "undated": undated,
        "unique": len(set(emails)),
        "dupes": len(emails) - len(set(emails)),
        "platform": plat,
        "from": min(dates).strftime("%b %-d") if dates else "",
        "to": max(dates).strftime("%b %-d") if dates else "",
        "toISO": max(dates).date().isoformat() if dates else "",
    }

(ROOT / "data").mkdir(exist_ok=True)
(ROOT / "data" / "leads.json").write_text(json.dumps(out, separators=(",", ":")))

for k, v in out.items():
    print(f"{k}: {len(v['rows'])} rows {v['from']}–{v['to']} "
          f"· by month {v['counts']} · undated {v['undated']} "
          f"· {v['unique']} unique emails ({v['dupes']} repeat) · platform {v['platform']}")
    bad = [x for x in v["rows"] if not x["e"] or "@" not in x["e"]
           or x["f"].lower() in ("ig", "fb")]
    print(f"   rows failing the shape check: {len(bad)}")
    for x in v["rows"][:2] + v["rows"][-2:]:
        print("   ", x["d"], "|", x["f"], "|", x["l"], "|",
              x["e"][:3] + "***", "|", x["p"], "|", x["src"])
print("bytes:", (ROOT / "data" / "leads.json").stat().st_size)
