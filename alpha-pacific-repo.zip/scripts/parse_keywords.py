#!/usr/bin/env python3
"""Parse the Google Ads keyword exports into data/keywords.json.

One file per property, tab separated, UTF-16 from Google Ads. Column sets differ
between files (the Onyx export carries an extra Currency code column), so every
field is looked up by header name rather than position.

Keywords are attributed by the ad group string, which names the property, so the
files could be merged or split without changing the result.
"""
import csv, json, re, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC  = ROOT / "build" / "csv"

PROP_MATCH = {
    "CAN": r"camino\s*al\s*norte",
    "ONX": r"\bonyx\b",
    "ELY": r"elysian|st\.?\s*rose",
}
MATCH_SHORT = {"Phrase match": "Phrase", "Exact match": "Exact", "Broad match": "Broad"}

def num(s):
    s = (s or "").strip().replace(",", "").replace("%", "").replace("$", "")
    if s in ("", "--", "-", "\u2014", " --"): return 0
    try:
        f = float(s)
        return int(f) if f == int(f) else round(f, 2)
    except: return 0

def clean_kw(k):
    k = (k or "").strip()
    k = re.sub(r'^"+|"+$', "", k)      # phrase-match quoting, doubled by the export
    k = re.sub(r"^\[|\]$", "", k)      # exact-match brackets
    return k.strip()

def short_group(g):
    """6784480_WY_Cheyenne_Alpha Pacific Capital_The Onyx Apartments_Branded -> Branded"""
    parts = [p for p in (g or "").split("_") if p]
    return parts[-1].strip() if parts else (g or "")

def prop_of(text):
    t = (text or "").lower()
    for k, rx in PROP_MATCH.items():
        if re.search(rx, t): return k
    return None

out, period = {}, None
for path in sorted(SRC.glob("alpha_*_kws.tsv")):
    rows = list(csv.reader(open(path), delimiter="\t"))
    if period is None:
        for r in rows[:4]:
            if r and re.search(r"\d{4}\s*-\s*\w+ \d{1,2}, \d{4}", r[0] or ""):
                period = r[0].strip('"')
    hi = next(i for i, r in enumerate(rows) if r and r[0] == "Keyword status")
    col = {h: i for i, h in enumerate(rows[hi])}
    g = lambda r, name: r[col[name]] if name in col and col[name] < len(r) else ""

    for r in rows[hi+1:]:
        if not r or len(r) < 5 or r[0].startswith("Total"): continue
        group = g(r, "Ad group")
        p = prop_of(group) or prop_of(g(r, "Keyword"))
        if not p: continue
        kw = clean_kw(g(r, "Keyword"))
        if not kw: continue
        imp, clk = num(g(r, "Impr.")), num(g(r, "Clicks"))
        rec = {
            "kw": kw,
            "match": MATCH_SHORT.get(g(r, "Match type"), g(r, "Match type")),
            "group": short_group(group),
            "impr": imp, "clicks": clk,
            "ctr": round(clk / imp * 100, 2) if imp else 0,
            "conv": num(g(r, "Conversions")),
            "cost": num(g(r, "Cost")),
            "cpc": num(g(r, "Avg. CPC")),
            "qs": num(g(r, "Quality Score")),
            "serving": (g(r, "Status") or "").strip(),
            "why": (g(r, "Status reasons") or "").strip(),
        }
        out.setdefault(p, []).append(rec)

result = {}
for p, rows in out.items():
    # merge duplicates on keyword + ad group
    m = {}
    for r in rows:
        k = (r["kw"], r["group"], r["match"])
        if k in m:
            e = m[k]
            e["impr"] += r["impr"]; e["clicks"] += r["clicks"]
            e["conv"] += r["conv"]; e["cost"] = round(e["cost"] + r["cost"], 2)
        else:
            m[k] = dict(r)
    rows = list(m.values())
    for r in rows:
        r["ctr"] = round(r["clicks"] / r["impr"] * 100, 2) if r["impr"] else 0
    live = sorted([r for r in rows if r["impr"] > 0], key=lambda r: -r["impr"])
    idle = [r for r in rows if r["impr"] == 0]
    # a keyword Google marks "Not eligible / rarely served" never had a chance to run
    rarely = [r for r in idle if "rarely" in (r["why"] or "").lower()]

    groups = {}
    for r in live:
        e = groups.setdefault(r["group"], {"impr":0,"clicks":0,"conv":0,"cost":0,"n":0})
        e["impr"] += r["impr"]; e["clicks"] += r["clicks"]
        e["conv"] += r["conv"]; e["cost"] = round(e["cost"] + r["cost"], 2); e["n"] += 1

    # The export window starts 13 Aug, but nothing served before the 19 Aug launch,
    # so the period is not carried through — it would only invite a false caveat.
    result[p] = {
        "rows": live,
        "idle": len(idle), "rarely": len(rarely),
        "totals": {"impr": sum(r["impr"] for r in live),
                   "clicks": sum(r["clicks"] for r in live),
                   "conv": round(sum(r["conv"] for r in live), 2),
                   "cost": round(sum(r["cost"] for r in live), 2)},
        "groups": groups,
    }

(ROOT / "data" / "keywords.json").write_text(json.dumps(result, separators=(",", ":")))

print("period:", period)
for p, v in result.items():
    t = v["totals"]
    print(f"  {p}: live={len(v['rows']):3d} idle={v['idle']:3d} (rarely served {v['rarely']:3d}) "
          f"impr={t['impr']:>6,} clicks={t['clicks']:>5,} conv={t['conv']} cost=${t['cost']:,.2f}")
    for gname, gv in sorted(v["groups"].items(), key=lambda x: -x[1]["impr"]):
        print(f"      {gname:34s} {gv['impr']:>6,} impr  {gv['clicks']:>4} clicks  {gv['n']} keywords")
print("bytes:", (ROOT / "data" / "keywords.json").stat().st_size)
